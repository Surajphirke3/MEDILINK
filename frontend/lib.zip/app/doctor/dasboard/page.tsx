import EmailVerification from '@/components/emailverification'
import React from 'react'

const page = () => {
  return (
    <div>doctor
        <EmailVerification/>
    </div>
  )
}

export default page