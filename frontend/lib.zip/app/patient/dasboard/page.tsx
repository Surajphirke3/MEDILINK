import React from 'react'

const page = () => {
  return (
    <div>patient</div>
  )
}

export default page